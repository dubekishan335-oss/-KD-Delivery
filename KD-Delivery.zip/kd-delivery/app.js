import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getFirestore,collection,onSnapshot,doc,getDoc,addDoc,serverTimestamp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {firebaseConfig} from "./config.js";
window.__kdLoaded=true;
const T={hi:{search:"सामान खोजें...",all:"सभी",add:"जोड़ें",cart:"🛒 कार्ट देखें",empty:"कार्ट खाली है",total:"कुल",name:"आपका नाम",mobile:"मोबाइल नंबर (10 अंक)",addr:"पूरा पता",map:"Google Maps लिंक (ज़रूरी नहीं)",note:"ऑर्डर नोट",loc:"📍 मेरी लोकेशन भेजें",ord:"ऑर्डर करें",close:"बंद करें",out:"माफ़ करें, आप डिलीवरी क्षेत्र से बाहर हैं।",inn:"✅ आप डिलीवरी क्षेत्र में हैं।",needloc:"पहले अपनी लोकेशन भेजें (ज़रूरी है)।",fill:"नाम, 10 अंक का मोबाइल और पता भरें।",done:"✅ ऑर्डर दर्ज हो गया! नीचे बटन से WhatsApp पर भी भेजें।",wa:"WhatsApp पर भेजें",na:"उपलब्ध नहीं",closed:"दुकान अभी बंद है।",err:"ऑर्डर नहीं हो सका। दोबारा कोशिश करें।",cfg:"सेटअप अधूरा है: config.js में Firebase जानकारी भरें।",st:"आपके ऑर्डर की स्थिति",Pending:"Pending (प्रतीक्षा)",Accepted:"Accepted (स्वीकार)",Preparing:"Preparing (तैयार हो रहा)","Out for Delivery":"Out for Delivery (रास्ते में)",Delivered:"Delivered (पहुँच गया)"},
en:{search:"Search items...",all:"All",add:"Add",cart:"🛒 View cart",empty:"Cart is empty",total:"Total",name:"Your name",mobile:"Mobile number (10 digits)",addr:"Full address",map:"Google Maps link (optional)",note:"Order notes",loc:"📍 Share my location",ord:"Place order",close:"Close",out:"Sorry, you are outside the delivery area.",inn:"✅ You are inside the delivery area.",needloc:"Please share your location first (required).",fill:"Fill name, 10-digit mobile and address.",done:"✅ Order placed! Also send it on WhatsApp using the button below.",wa:"Send on WhatsApp",na:"Unavailable",closed:"Shop is closed right now.",err:"Order failed. Please try again.",cfg:"Setup incomplete: add Firebase details in config.js.",st:"Your order status",Pending:"Pending",Accepted:"Accepted",Preparing:"Preparing","Out for Delivery":"Out for Delivery",Delivered:"Delivered"}};
const $=id=>document.getElementById(id),esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}},sv=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let loaded=false,lang=ld("kd_lang","hi"),cat="all",cart=ld("kd_cart",{}),loc=null,P=[],S={lat:0,lng:0,radiusKm:3,whatsapp:"",open:true},db=null;
const t=k=>T[lang][k];
const ok=!firebaseConfig.apiKey.startsWith("YOUR");
if(ok){db=getFirestore(initializeApp(firebaseConfig));
 onSnapshot(collection(db,"products"),s=>{P=s.docs.map(d=>({id:d.id,...d.data()}));loaded=true;render()});
 getDoc(doc(db,"settings","main")).then(d=>{if(d.exists())S={...S,...d.data()}});
 const last=localStorage.getItem("kd_last");if(last)getDoc(doc(db,"orders",last)).then(d=>{if(d.exists())$("track").innerHTML=`<div class="msg ok">${t("st")}: <b>${t(d.data().status)||d.data().status}</b></div>`}).catch(()=>{});
}else $("grid").innerHTML=`<div class="msg warn">${T.hi.cfg}</div>`;
const total=()=>P.reduce((s,p)=>s+(cart[p.id]||0)*p.p,0),count=()=>Object.values(cart).reduce((a,b)=>a+b,0);
function render(){$("q").placeholder=t("search");$("lang").textContent=lang=="hi"?"EN":"हिं";
 document.querySelectorAll("[data-hi]").forEach(e=>e.textContent=e.dataset[lang]);
 const cs=["all",...new Set(P.map(p=>p.c).filter(Boolean))];
 $("cats").innerHTML=cs.map(c=>`<button class="${c==cat?"on":""}" data-c="${esc(c)}">${c=="all"?t("all"):esc(c)}</button>`).join("");
 const q=$("q").value.toLowerCase();
 if(ok&&loaded)$("grid").innerHTML=P.filter(p=>(cat=="all"||p.c==cat)&&(p.n||"").toLowerCase().includes(q)).map(p=>`<div class="card"><div class="img">${p.img?`<img src="${p.img}">`:esc(p.e)||"📦"}</div><h3>${esc(p.n)}</h3><p>${esc(p.d)}</p><div class="price">₹${p.p}</div>${!p.a?`<button class="btn" disabled>${t("na")}</button>`:cart[p.id]?`<div class="qty"><button data-m="${p.id}">−</button><b>${cart[p.id]}</b><button data-a="${p.id}">+</button></div>`:`<button class="btn" data-a="${p.id}">${t("add")}</button>`}</div>`).join("");
 if(ok&&loaded&&!$("grid").children.length)$("grid").innerHTML=`<div class="msg" style="grid-column:1/-1">📦 ${lang=="hi"?"अभी कोई प्रोडक्ट नहीं है।":"No products yet."}</div>`;
 $("cartBtn").textContent=`${t("cart")} (${count()}) • ₹${total()}`;sv("kd_cart",cart);}
function dist(a,b,c,d){const r=x=>x*Math.PI/180,h=Math.sin(r(c-a)/2)**2+Math.cos(r(a))*Math.cos(r(c))*Math.sin(r(d-b)/2)**2;return 12742*Math.asin(Math.sqrt(h))}
const open=h=>{$("sheet").innerHTML=h;$("sheet").hidden=false},shut=()=>{$("sheet").hidden=true;render()};
function cartView(){const items=P.filter(p=>cart[p.id]);
 if(!items.length){open(`<h2>${t("cart")}</h2><p>${t("empty")}</p><button class="btn alt" id="x">${t("close")}</button>`);$("x").onclick=shut;return}
 const keep=["cn","cm","ca","cl","co"].map(i=>$(i)?.value||"");
 open(`<h2>${t("cart")}</h2>${items.map(p=>`<div class="row"><span>${esc(p.n)} ₹${p.p}</span><span class="qty"><button data-m="${p.id}">−</button><b>${cart[p.id]}</b><button data-a="${p.id}">+</button></span></div>`).join("")}
 <h3>${t("total")}: ₹${total()}</h3><input id="cn" placeholder="${t("name")}"><input id="cm" type="tel" maxlength="10" placeholder="${t("mobile")}"><textarea id="ca" placeholder="${t("addr")}"></textarea><input id="cl" placeholder="${t("map")}"><textarea id="co" placeholder="${t("note")}"></textarea>
 <button class="btn alt" id="gl">${t("loc")}</button><div id="lm"></div><button class="btn" id="go">${t("ord")}</button><button class="btn alt" id="x">${t("close")}</button>`);
 ["cn","cm","ca","cl","co"].forEach((i,k)=>$(i).value=keep[k]);msg();
 $("x").onclick=shut;$("gl").onclick=getLoc;$("go").onclick=send;}
const inArea=()=>loc&&dist(S.lat,S.lng,loc.lat,loc.lng)<=S.radiusKm;
function msg(m){if(!$("lm"))return;$("lm").innerHTML=m?`<div class="msg warn">${m}</div>`:loc?`<div class="msg ${inArea()?"ok":"warn"}">${inArea()?t("inn"):t("out")}</div>`:""}
function getLoc(){navigator.geolocation?.getCurrentPosition(g=>{loc={lat:g.coords.latitude,lng:g.coords.longitude};msg()},()=>msg(t("needloc")),{enableHighAccuracy:true,timeout:15000})}
async function send(){const n=$("cn").value.trim(),m=$("cm").value.trim(),a=$("ca").value.trim();
 if(S.open===false)return msg(t("closed"));
 if(!n||!/^\d{10}$/.test(m)||!a)return msg(t("fill"));
 if(!loc)return msg(t("needloc"));if(!inArea())return msg(t("out"));
 const items=P.filter(p=>cart[p.id]).map(p=>({n:p.n,q:cart[p.id],p:p.p})),link=$("cl").value.trim()||`https://maps.google.com/?q=${loc.lat},${loc.lng}`;
 $("go").disabled=true;
 try{const r=await addDoc(collection(db,"orders"),{name:n,mobile:m,address:a,mapLink:link,note:$("co").value.trim(),items,total:total(),lat:loc.lat,lng:loc.lng,status:"Pending",createdAt:serverTimestamp()});
  localStorage.setItem("kd_last",r.id);
  const txt=`*KD Delivery ऑर्डर* #${r.id.slice(0,6)}\n${items.map(i=>`${i.n} x${i.q} = ₹${i.q*i.p}`).join("\n")}\n*कुल: ₹${total()}*\nनाम: ${n}\nमोबाइल: ${m}\nपता: ${a}\nलोकेशन: ${link}`;
  cart={};sv("kd_cart",cart);
  open(`<div class="msg ok">${t("done")}</div><a class="btn" style="display:block;text-align:center;text-decoration:none" target="_blank" href="https://wa.me/${S.whatsapp}?text=${encodeURIComponent(txt)}">${t("wa")}</a><button class="btn alt" id="x">${t("close")}</button>`);$("x").onclick=()=>{shut();location.reload()};
 }catch(e){console.error(e);$("go").disabled=false;msg(t("err"))}}
document.addEventListener("click",e=>{const d=e.target.dataset;if(!d)return;
 if(d.c){cat=d.c;render()}else if(d.a||d.m){const id=d.a||d.m;cart[id]=Math.max(0,(cart[id]||0)+(d.a?1:-1));if(!cart[id])delete cart[id];render();if(!$("sheet").hidden)cartView()}});
$("q").oninput=render;$("cartBtn").onclick=cartView;$("lang").onclick=()=>{lang=lang=="hi"?"en":"hi";sv("kd_lang",lang);render()};render();
