import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getAuth,signInWithEmailAndPassword,onAuthStateChanged,signOut} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {getFirestore,collection,onSnapshot,doc,getDoc,setDoc,addDoc,updateDoc,deleteDoc,query,orderBy} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {firebaseConfig} from "./config.js";
const $=id=>document.getElementById(id),app=$("app"),esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ST=["Pending","Accepted","Preparing","Out for Delivery","Delivered"];
if(firebaseConfig.apiKey.startsWith("YOUR")){app.innerHTML='<div class="msg warn">config.js में Firebase जानकारी भरें।</div>'}else{
const auth=getAuth(initializeApp(firebaseConfig)),db=getFirestore(auth.app);let unsubs=[],tab="o",O=[],P=[],first=true,edit=null,S={};
$("out").onclick=()=>signOut(auth);
function beep(){try{const c=new AudioContext(),o=c.createOscillator();o.connect(c.destination);o.frequency.value=880;o.start();setTimeout(()=>o.stop(),700)}catch(e){}}
function login(m=""){$("out").hidden=true;app.innerHTML=`<h2>Admin Login</h2>${m?`<div class="msg warn">${m}</div>`:""}<input id="em" type="email" placeholder="Email"><input id="pw" type="password" placeholder="Password"><button class="btn" id="li">Login</button>`;
 $("li").onclick=()=>signInWithEmailAndPassword(auth,$("em").value,$("pw").value).catch(()=>login("ईमेल या पासवर्ड गलत है।"))}
onAuthStateChanged(auth,async u=>{unsubs.forEach(f=>f());unsubs=[];if(!u)return login();
 try{const a=await getDoc(doc(db,"admins",u.uid));if(!a.exists()){await signOut(auth);return login("यह खाता एडमिन नहीं है।")}}catch(e){await signOut(auth);return login("एडमिन जाँच नहीं हो सकी।")}
 $("out").hidden=false;first=true;
 unsubs.push(onSnapshot(query(collection(db,"orders"),orderBy("createdAt","desc")),s=>{
  if(!first&&s.docChanges().some(c=>c.type=="added")){beep();navigator.vibrate?.(300);if(Notification.permission=="granted")new Notification("KD Delivery: नया ऑर्डर!")}
  first=false;O=s.docs.map(d=>({id:d.id,...d.data()}));draw()}));
 unsubs.push(onSnapshot(collection(db,"products"),s=>{P=s.docs.map(d=>({id:d.id,...d.data()}));draw()}));
 unsubs.push(onSnapshot(doc(db,"settings","main"),d=>{S=d.data()||{};draw()}));});
function draw(){if(edit!==null&&tab=="p"&&document.activeElement&&app.contains(document.activeElement)&&["INPUT","TEXTAREA"].includes(document.activeElement.tagName))return;
 const tb=`<div class="tabs">${[["o","ऑर्डर"],["p","प्रोडक्ट"],["s","सेटिंग"]].map(([k,l])=>`<button data-t="${k}" class="${tab==k?"on":""}">${l}</button>`).join("")}</div>`;
 if(tab=="o")app.innerHTML=tb+`<button class="btn alt" id="nt">🔔 Notification चालू करें</button>`+(O.length?"":"<p>कोई ऑर्डर नहीं।</p>")+O.map(x=>`<div class="card ${x.status=="Pending"?"new":""}" style="margin:8px 0"><b>${esc(x.name)}</b> • <a href="tel:${esc(x.mobile)}">${esc(x.mobile)}</a><br>${esc(x.address)}<br><a href="${esc(x.mapLink)}" target="_blank">📍 Map</a><br>${(x.items||[]).map(i=>esc(i.n)+" x"+i.q).join(", ")}<br>${x.note?"नोट: "+esc(x.note)+"<br>":""}<b>₹${x.total}</b><select data-s="${x.id}">${ST.map(s=>`<option ${s==x.status?"selected":""}>${s}</option>`).join("")}</select></div>`).join("");
 if(tab=="p"){const e=P.find(p=>p.id==edit)||{};app.innerHTML=tb+`<h3>${edit?"एडिट":"नया प्रोडक्ट"}</h3><input id="pn" placeholder="नाम" value="${esc(e.n)}"><input id="pp" type="number" placeholder="कीमत ₹" value="${e.p??""}"><input id="pd" placeholder="विवरण" value="${esc(e.d)}"><input id="pc" placeholder="श्रेणी" value="${esc(e.c)}"><input id="pe" placeholder="इमोजी (फोटो न हो तो)" value="${esc(e.e)}"><label><input id="pa" type="checkbox" style="width:auto" ${e.a!==false?"checked":""}> उपलब्ध</label><input id="pi" type="file" accept="image/*"><button class="btn" id="ps">सहेजें</button>${edit?'<button class="btn alt" id="pcn">रद्द</button>':""}<h3>प्रोडक्ट</h3>`+P.map(p=>`<div class="row"><span>${esc(p.n)} ₹${p.p} ${p.a?"":"(बंद)"}</span><span><button data-e="${p.id}">✏️</button> <button data-d="${p.id}">🗑</button></span></div>`).join("")}
 if(tab=="s")app.innerHTML=tb+`<h3>डिलीवरी क्षेत्र व सेटिंग</h3><p>गाँव के केंद्र की Latitude/Longitude (Google Maps में जगह दबाकर देखें)</p><input id="sl" type="number" step="any" placeholder="Latitude" value="${S.lat??""}"><input id="sg" type="number" step="any" placeholder="Longitude" value="${S.lng??""}"><input id="sr" type="number" step="any" placeholder="त्रिज्या (km)" value="${S.radiusKm??3}"><input id="sw" placeholder="WhatsApp नंबर 91XXXXXXXXXX" value="${esc(S.whatsapp)}"><label><input id="so" type="checkbox" style="width:auto" ${S.open!==false?"checked":""}> दुकान खुली है</label><button class="btn" id="ss">सहेजें</button><div id="sm"></div>`}
app.addEventListener("click",async e=>{const d=e.target.dataset,id=e.target.id;
 if(d.t){tab=d.t;edit=null;draw()}else if(d.e){edit=d.e;draw()}else if(d.d&&confirm("हटाएँ?"))deleteDoc(doc(db,"products",d.d));
 else if(id=="nt")Notification.requestPermission();else if(id=="pcn"){edit=null;draw()}
 else if(id=="ss"){const w=$("sw").value.replace(/\D/g,"");await setDoc(doc(db,"settings","main"),{lat:+$("sl").value,lng:+$("sg").value,radiusKm:+$("sr").value||3,whatsapp:w,open:$("so").checked});$("sm").innerHTML='<div class="msg ok">सहेज लिया ✅</div>'}
 else if(id=="ps"){const f=$("pi").files[0],data={n:$("pn").value.trim(),p:+$("pp").value,d:$("pd").value.trim(),c:$("pc").value.trim()||"अन्य",e:$("pe").value.trim(),a:$("pa").checked};if(!data.n||!(data.p>=0))return;
  const done=async img=>{if(img)data.img=img;edit?await updateDoc(doc(db,"products",edit),data):await addDoc(collection(db,"products"),data);edit=null;draw()};
  if(!f)return done();const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement("canvas");c.width=400;c.height=Math.round(400*im.height/im.width);c.getContext("2d").drawImage(im,0,0,c.width,c.height);done(c.toDataURL("image/jpeg",.6))};im.src=r.result};r.readAsDataURL(f)}});
app.addEventListener("change",e=>{if(e.target.dataset.s)updateDoc(doc(db,"orders",e.target.dataset.s),{status:e.target.value})});}
