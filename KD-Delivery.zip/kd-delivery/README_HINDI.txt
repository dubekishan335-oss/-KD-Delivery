KD Delivery - पूरा सेटअप (सिर्फ Android फ़ोन से)

क्या-क्या है: ग्राहक साइट (index.html), सुरक्षित एडमिन (admin.html, Firebase लॉगिन), साझा ऑनलाइन डेटाबेस (Firestore), डिलीवरी-क्षेत्र की रोक, WhatsApp ऑर्डर, ऑर्डर स्टेटस।
खर्च: Firebase Spark प्लान मुफ़्त है, कार्ड नहीं लगता। फ़ोटो Firebase Storage में नहीं, छोटी करके डेटाबेस में रखी जाती हैं (Storage के लिए पेड प्लान लगता है, इसलिए नहीं लिया)।
सीमाएँ: (1) एडमिन पेज खुला होने पर ही नए ऑर्डर की आवाज़/नोटिफ़िकेशन आता है; पेज बंद होने पर पुश के लिए Cloud Functions चाहिए जो पेड है, इसलिए नहीं जोड़ा। (2) सर्वर नियम सिर्फ मोटा चौकोर क्षेत्र जाँचते हैं, सही गोल जाँच ऐप में होती है। (3) कुल रकम सर्वर पर कीमतों से नहीं मिलाई जाती; एडमिन आइटम देखकर पुष्टि करें। (4) यह कोड मैं असली Firebase से टेस्ट नहीं कर पाया; आपको नीचे का टेस्ट (चरण 12) करना है।

भाग A - Firebase (फ़ोन में Chrome, "Desktop site" चालू)
1. console.firebase.google.com > Google से लॉगिन > Add project > नाम kd-delivery > Analytics बंद > Create।
2. Project Overview पर </> (Web) आइकन > नाम kd-web > Register app। जो firebaseConfig दिखे उसकी apiKey, authDomain, projectId, appId कॉपी कर लें।
3. Build > Authentication > Get started > Sign-in method > Email/Password चालू > Save।
4. Authentication > Users > Add user > अपना ईमेल और मज़बूत पासवर्ड डालें। बनने के बाद उस यूज़र की "User UID" कॉपी करें।
5. Build > Firestore Database > Create database > Location: asia-south1 (Mumbai) > Production mode > Create।
6. Firestore > Rules टैब > सब मिटाकर firestore.rules की पूरी लिखावट चिपकाएँ > Publish।
7. Firestore > Data > Start collection > नाम: admins > Document ID में वही UID चिपकाएँ > Field: role, Value: admin > Save। (सिर्फ यही खाता एडमिन बनेगा।)

भाग B - GitHub (ZIP extract करने के बाद)
8. github.com > New repository > kd-delivery > Public > Create > "uploading an existing file" > सभी फ़ाइलें चुनें (firestore.rules वैकल्पिक) > Commit। पहले config.js GitHub में खोलकर (Edit) चरण 2 की चारों जानकारी भरें > Commit।
9. Settings > Pages > Deploy from a branch > main /(root) > Save। लिंक बनेगा: https://आपकानाम.github.io/kd-delivery/
10. Firebase > Authentication > Settings > Authorized domains > Add domain > आपकानाम.github.io जोड़ें (इसके बिना एडमिन लॉगिन नहीं चलेगा)।

भाग C - चालू करना और टेस्ट
11. लिंक/admin.html खोलें > लॉगिन > "सेटिंग" टैब: गाँव के केंद्र की Latitude/Longitude (Google Maps में जगह दबाकर ऊपर के अंक), त्रिज्या km, WhatsApp नंबर (91 के साथ) भरें, "दुकान खुली है" टिक करें > सहेजें। यह पहले ज़रूरी है, इसके बिना ऑर्डर नहीं जाएँगे। फिर "प्रोडक्ट" टैब में सामान और फ़ोटो जोड़ें। "ऑर्डर" टैब में "Notification चालू करें" दबाएँ।
12. टेस्ट: दूसरे फ़ोन/टैब में मुख्य लिंक खोलें > सामान जोड़ें > कार्ट > लोकेशन भेजें > ऑर्डर करें। एडमिन में ऑर्डर और आवाज़ आनी चाहिए; स्टेटस बदलने पर ग्राहक को ऊपर नई स्थिति दिखे। गाँव से बाहर की लोकेशन पर "बाहर हैं" संदेश आना चाहिए। कुछ न चले तो Firebase Rules/Authorized domains फिर जाँचें।

ज़रूरी: index.html को फ़ोन की फ़ाइल से सीधे खोलने पर डेटा नहीं दिखेगा (ब्राउज़र रोकता है)। हमेशा GitHub Pages का लिंक खोलें।
