// KD Delivery - Firebase config. Firebase Console > Project settings > Your apps > Web app se copy karke yahan paste karein.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  appId: "YOUR_APP_ID"
};
// Delivery area, WhatsApp number aur dukaan open/close ab Admin panel > Settings se badalte hain.
